from setuptools import setup

setup(

    name="paquetecalculos",
    version="1.0",
    description="Paquete de redondeo y potencia",
    author="David",
    author_email="dsjaramillo@hotmail.com",
    url="www.pildorasinformaticas.es",
    packages=["calculos", "calculos.redondeo_potencia"]

)
