def potencia(base,exponente):
    print("el resultado del exponente es: ",base**exponente)

def redondear(numero):
    print("el resultado de redondear", numero, "es: ", round(numero))
