def sumar(op1,op2):
    print("El resultado de la suma es:",op1+op2)

def restar(op1,op2):
    print("El resultado de la resta es:",op1-op2)

def multiplicar(op1,op2):
    print("El resultado de la multiplicacion es:",op1*op2)

def dividir(op1,op2):
    print("El resultado de la división es:",op1/op2)

def potencia(base,exponente):
    print("el resultado del exponente es: ",base**exponente)

def redondear(numero):
    print("el resultado de redondear", numero, "es: ", round(numero))
